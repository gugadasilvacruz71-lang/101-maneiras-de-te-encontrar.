# 101 maneiras de te encontrar ♡

Página romântica responsiva com contagem regressiva e liberação da playlist validada pelo servidor.

## Horário configurado

7 de novembro de 2026, às 19h54, no fuso `America/Sao_Paulo` (UTC-03:00 nesta data).

## Rodar localmente

Requer Node.js 18 ou superior. O servidor usa apenas módulos nativos do Node.js, sem dependências externas.

```bash
cp .env.example .env
# Preencha SPOTIFY_URL no arquivo .env antes de iniciar
npm start
```

Abra `http://localhost:3000`.

O arquivo `.env` contém a URL secreta e não deve ser enviado ao GitHub ou colocado na pasta pública do site. O `.env` já está no `.gitignore`.

## Publicar no Render

1. Envie esta pasta para um repositório privado no GitHub.
2. No Render, crie um **Web Service** conectado ao repositório.
3. Use `npm start` como Start Command. Como não há dependências externas, o Build Command pode ficar em branco ou usar `npm install`.
4. Adicione as variáveis de ambiente:
   - `UNLOCK_AT` = `2026-11-07T19:54:00-03:00`
   - `SPOTIFY_URL` = URL completa da playlist enviada por você.
5. Publique o serviço. O Render define a variável `PORT` automaticamente.

## Como funciona o bloqueio

O navegador consulta `/api/status`, mas antes do horário o servidor responde somente com `unlocked: false`, horário do servidor e horário de liberação. A URL do Spotify só é incluída na resposta depois de `Date.now() >= UNLOCK_AT` no servidor. A URL não aparece no HTML, CSS ou JavaScript público.

O cronômetro usa a hora do servidor para evitar depender do relógio do celular. Se a consulta ao servidor falhar, o contador continua como referência visual, mas o botão não é liberado.

## Observação

O bloqueio impede que a própria página revele a URL antes do horário. Ele não torna a playlist privada no Spotify nem impede que alguém que já tenha o link a abra por fora. Depois de 19h54, qualquer pessoa que acessar o endpoint de status poderá obter a URL liberada.
