(() => {
  const els = {
    days: document.getElementById('days'),
    hours: document.getElementById('hours'),
    minutes: document.getElementById('minutes'),
    seconds: document.getElementById('seconds'),
    note: document.getElementById('unlock-note'),
    button: document.getElementById('spotify-button'),
    progress: document.getElementById('progress-bar'),
    card: document.querySelector('.countdown-card'),
    lock: document.getElementById('lock-seal')
  };

  let serverOffset = 0;
  let releaseAt = new Date('2026-11-07T19:54:00-03:00').getTime();
  let unlocked = false;
  let spotifyUrl = null;
  let initialRemaining = null;

  const pad = (n) => String(n).padStart(2, '0');

  function renderTimer() {
    const now = Date.now() + serverOffset;
    const remaining = Math.max(0, releaseAt - now);
    const totalSeconds = Math.floor(remaining / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    els.days.textContent = pad(days);
    els.hours.textContent = pad(hours);
    els.minutes.textContent = pad(minutes);
    els.seconds.textContent = pad(seconds);

    const totalWindow = 24 * 60 * 60 * 1000;
    const elapsed = initialRemaining === null ? 0 : Math.max(0, initialRemaining - remaining);
    const progress = initialRemaining && initialRemaining > 0 ? (elapsed / initialRemaining) * 100 : 0;
    els.progress.style.width = `${Math.min(100, Math.max(2, progress))}%`;

    if (unlocked) showUnlocked();
  }

  function showUnlocked() {
    if (!spotifyUrl) return;
    els.card.classList.add('is-unlocked');
    els.lock.innerHTML = '<span class="lock-icon">♡</span><span>é sua</span>';
    els.days.textContent = '00';
    els.hours.textContent = '00';
    els.minutes.textContent = '00';
    els.seconds.textContent = '00';
    els.progress.style.width = '100%';
    els.note.textContent = 'O momento chegou. Cada faixa guarda um jeito diferente de lembrar de você.';
    els.button.href = spotifyUrl;
    els.button.classList.remove('is-hidden');
  }

  async function syncWithServer() {
    try {
      const response = await fetch(`/api/status?t=${Date.now()}`, {
        cache: 'no-store',
        headers: { 'Accept': 'application/json' }
      });
      if (!response.ok) throw new Error('Não foi possível consultar o relógio do servidor.');
      const data = await response.json();
      serverOffset = data.serverNow - Date.now();
      releaseAt = data.unlockAt;
      if (initialRemaining === null) initialRemaining = Math.max(0, releaseAt - data.serverNow);
      if (data.unlocked && typeof data.spotifyUrl === 'string') {
        spotifyUrl = data.spotifyUrl;
        unlocked = true;
        showUnlocked();
      }
    } catch (error) {
      // O cronômetro continua usando o relógio do aparelho; o link nunca é liberado sem confirmação do servidor.
      console.warn('Sincronização temporariamente indisponível. Tentaremos novamente.', error);
    }
  }

  renderTimer();
  syncWithServer();
  window.setInterval(renderTimer, 250);
  window.setInterval(syncWithServer, 4000);
})();
