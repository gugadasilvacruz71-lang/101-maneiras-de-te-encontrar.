const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, 'public');

// Carrega um .env local sem sobrescrever variáveis já definidas pelo provedor.
try {
  const envFile = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  for (const line of envFile.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && process.env[match[1]] === undefined) {
      process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
    }
  }
} catch (error) {
  if (error.code !== 'ENOENT') throw error;
}

const PORT = Number(process.env.PORT || 3000);
const unlockAtRaw = process.env.UNLOCK_AT || '2026-11-07T19:54:00-03:00';
const unlockAt = Date.parse(unlockAtRaw);
const spotifyUrl = process.env.SPOTIFY_URL;

if (!Number.isFinite(unlockAt)) {
  console.error('UNLOCK_AT inválido. Use uma data ISO 8601 com fuso horário.');
  process.exit(1);
}

if (!spotifyUrl) {
  console.error('Defina SPOTIFY_URL nas variáveis de ambiente ou no arquivo .env.');
  process.exit(1);
}

try {
  const parsed = new URL(spotifyUrl);
  if (parsed.protocol !== 'https:' || parsed.hostname !== 'open.spotify.com') {
    throw new Error('A URL deve ser HTTPS e pertencer a open.spotify.com.');
  }
} catch (error) {
  console.error(`SPOTIFY_URL inválida: ${error.message}`);
  process.exit(1);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon'
};

function send(res, status, contentType, body) {
  res.writeHead(status, {
    'Content-Type': contentType,
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'X-Frame-Options': 'DENY',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  let requestUrl;
  try {
    requestUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  } catch {
    return send(res, 400, 'text/plain; charset=utf-8', 'Requisição inválida.');
  }

  if (requestUrl.pathname === '/api/status') {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return send(res, 405, 'application/json; charset=utf-8', JSON.stringify({ error: 'Método não permitido.' }));
    }

    const now = Date.now();
    const unlocked = now >= unlockAt;
    const payload = { unlocked, serverNow: now, unlockAt };

    // A URL só cruza a fronteira do servidor depois do horário configurado.
    if (unlocked) payload.spotifyUrl = spotifyUrl;
    return send(res, 200, 'application/json; charset=utf-8', req.method === 'HEAD' ? '' : JSON.stringify(payload));
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, 'text/plain; charset=utf-8', 'Método não permitido.');
  }

  let relativePath;
  try {
    relativePath = decodeURIComponent(requestUrl.pathname === '/' ? '/index.html' : requestUrl.pathname);
  } catch {
    return send(res, 400, 'text/plain; charset=utf-8', 'Caminho inválido.');
  }

  const filePath = path.resolve(ROOT, `.${relativePath}`);
  if (!filePath.startsWith(`${ROOT}${path.sep}`)) {
    return send(res, 403, 'text/plain; charset=utf-8', 'Acesso negado.');
  }

  fs.readFile(filePath, (error, data) => {
    if (error) return send(res, 404, 'text/plain; charset=utf-8', 'Página não encontrada.');
    const contentType = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
    return send(res, 200, contentType, req.method === 'HEAD' ? '' : data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Página disponível na porta ${PORT}`);
});
